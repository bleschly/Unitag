import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached


@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    allshares = db.execute("SELECT symbol, SUM(amount) FROM stock WHERE id = :id GROUP BY symbol", id=session["user_id"])
    cash = db.execute("SELECT cash FROM users WHERE id = :id;", id=session["user_id"])
    balance = 0
    newallshares = []
    if allshares == [{'symbol': None, 'SUM(amount)': None}]:
        return render_template("index.html", allshares={})
    else:
        for numshares in allshares:
            numshares["price"] = lookup(numshares["symbol"])["price"]
            balance += numshares["price"]
            numshares["total"] = usd(numshares["price"] * numshares["SUM(amount)"])
            numshares["price"] = usd(numshares["price"])
            numshares["name"] = lookup(numshares["symbol"])["name"]
        balance += cash[0]["cash"]
        for numshares in allshares:
            if numshares["SUM(amount)"] != 0:
                newallshares.append(numshares)
    if allshares == [{'symbol': None, 'SUM(amount)': None}]:
        return render_template("index.html", allshares={})

    return render_template("index.html", allshares=newallshares, cash=usd(cash[0]["cash"]), balance=usd(balance))


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":
        # test if things are there
        if not request.form.get("symbol"):
            return apology("enter symbol")
        if not request.form.get("num"):
            return apology("enter num")
        symbol = request.form.get("symbol")
        shares = int(request.form.get("num"))
        if shares < 0:
            return apology("must be positive")
        # ensure symbol exists
        if not lookup(symbol):
            return apology("symbol not found")
        price = float(lookup(symbol)["price"])
        cash = db.execute("SELECT * FROM users WHERE id = :id", id=session["user_id"])
        if cash[0]["cash"] - (price * shares) < 0:
            return apology("you do not have the money for that purchase")
        else:
            # logging and adding to the proper tables
            db.execute("UPDATE users SET cash = :cash WHERE id = :id ",
                            cash = cash[0]["cash"] - (price * shares), id=session["user_id"] )
            db.execute("INSERT INTO stock (id, price, time, amount, symbol) VALUES (:id, :price, datetime('now'), :amount, :symbol);",
                            id = session["user_id"], symbol=symbol, price=price, amount=shares)
        return redirect("/")
    else:
        return render_template("buy.html")


@app.route("/check", methods=["GET"])
def check():
    """Return true if username available, else false, in JSON format"""
    q = request.args.get("username")
    rows = db.execute("SELECT username FROM users")
    for row in rows:
        if row["username"] == q:    # sent the user name and returns the jsonify boolean
            return jsonify(False)
    return jsonify(True)


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    if request.method == "GET":
        # basically print everything
        trans = db.execute("SELECT * FROM stock WHERE id = :id", id=session["user_id"])
        for tran in trans:
            tran["price"] = usd(tran["price"])
        return render_template("history.html", trans=trans)


@app.route("/cash", methods=["GET", "POST"])
def cash():
    """Deposit User Cash"""
    if request.method == "POST":

        number = float(request.form.get("num"))
        cash = db.execute("SELECT cash FROM users WHERE id = :id", id=session["user_id"])
        db.execute("UPDATE users SET cash = :cash WHERE id = :id ", cash=cash[0]["cash"] + number, id=session["user_id"])
        # deposit more cash
        return redirect("/")
    else:
        return render_template("cash.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    if request.method == "POST":
        """Get stock quote."""
        if not request.form.get("symbol"):
            return apology("enter symbol")
        symbol = request.form.get("symbol")
        # checks symbols existance
        if not lookup(symbol):
            return apology("symbol not found")
        quote = lookup(symbol)
        return render_template("quoted.html", quote=quote)
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET"])
def get_register():
    """Register user"""
    return render_template("register.html")


@app.route("/register", methods=["POST"])
def register():
    if request.method == "POST":
        if not request.form.get("username"):
            return apology("Please fill out username")
        if not request.form.get("password"):
            return apology("Please fill out password")
        if not request.form.get("confirmation"):
            return apology("Please confirm password")
        if request.form.get("confirmation") != request.form.get("password"):
            return apology("Password and confirmation do not agree")

        username = request.form.get("username")

        phash = generate_password_hash(request.form.get("password"), method='pbkdf2:sha256', salt_length=8)

        end = db.execute("INSERT INTO users (username, hash) VALUES (:username, :phash);", username=username, phash=phash)
        if not end:
            return apology(("This username is already taken"))
        session["user_id"] = end
        return redirect("/")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    if request.method == "POST":
        if not request.form.get("symbol"):
            return apology("enter symbol")
        symbol = request.form.get("symbol")
        shares = int(request.form.get("num"))
        if not lookup(symbol):
            return apology("symbol not found")
        price = float(lookup(symbol)["price"])
        # gets the proper amounts and variables
        amount = db.execute("SELECT symbol, SUM(amount) FROM stock WHERE id = :id AND symbol = :symbol",
                              id =session["user_id"], symbol = symbol)
        cash = db.execute("SELECT cash FROM users WHERE id = :id", id = session["user_id"])

        if amount[0]["SUM(amount)"] - (shares) < 0:
            return apology("you do not have the shares for that sale")
        else:
            # gets proper amounts and variables
            db.execute("UPDATE users SET cash = :cash WHERE id = :id ",
                            cash = cash[0]["cash"] + (price * shares), id=session["user_id"])
            db.execute("INSERT INTO stock (id, price, time, amount, symbol) VALUES (:id, :price, datetime('now'), :amount, :symbol);",
                            id = session["user_id"], symbol=symbol, price=price, amount=-(shares))
        return redirect("/")
    else:
        return render_template("sell.html")

    """Sell shares of stock"""
    return apology("TODO")


def errorhandler(e):
    """Handle error"""
    return apology(e.name, e.code)


# listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
